www.pcgamingrace.com
Glorious Model D Software (version 1.0.3)

----------
** ADVANCE FUNCTIONS **
In the Model D software, you will notice a setting called "Debounce Time". The default value of this is 10ms. 

The debounce setting is an adjustable setting in the Model D software that improves the mouse click latency. 
The lower the mouse click latency, the higher risk of double clicking. This setting is useful for playing around with 
if your mouse clicks start double clicking and other advance tests.


----------
** OTHER NOTES **
If you have issues with saving settings to mouse, please run EXE as admin.

Please note: Under Mouse Parameter, the option of Improve Pointer Precision is tied to your Windows settings. We recommend you disable this option for gaming.


----------
Changelog:

1/14/20 - v1.0.3
* First release.

----------